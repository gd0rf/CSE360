package application;

import application.user;

import java.io.IOException;

import javafx.application.Application;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;


import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


public class Main extends Application {

    private Stage primaryStage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        showMainScene();
    }

    private void showMainScene() {
        try {
        	FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            primaryStage.setTitle("Login Demo-Gebauer,Gannon");
            primaryStage.setScene(scene);
            primaryStage.show();
            
            
            MainController mainController = loader.getController();
            mainController.init(this);  // Pass a reference to the main app to the controller
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showHomeScene() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("home.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.show();
            
            
            
            MainController mainController = loader.getController();
            mainController.init(this);  // Pass a reference to the main app to the controller
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    

    

    public static class MainController {
        private Main mainApp;
        public TextField usernameTextField;
        public TextField passwordTextField;
        private user person;
        
        public void init(Main mainApp) {
            this.mainApp = mainApp;
        }

        @FXML
        public void login() {
            // Handle button click
            String username = usernameTextField.getText();
            System.out.println("Username: " + username);
            
            String password = passwordTextField.getText();
            System.out.println("Password: " + password);
            
            if (authenticateUser(username, password)) {
            	mainApp.showHomeScene(); // Switch to another scene
            } else {
            	mainApp.showMainScene(); // Handle unsuccessful login
            }            
        }
        
        @FXML
        public void logout() {
            // Handle logout button click
            mainApp.showMainScene(); // Switch to login scene or another appropriate scene
        }
        
        private boolean authenticateUser(String username, String password) {
            // Implement your authentication logic here
            // For simplicity, let's assume any non-empty username and password is valid
            return username != null && !username.isEmpty() && password != null && !password.isEmpty();
        }
        
    }
    
    
}
